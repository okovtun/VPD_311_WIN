Setup.msi - калькулятор
SetupClock.msi - часики